<!DOCTYPE html>
<html>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title> 
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
</head>

<body>
    <div class="MenuSelection">
        <h1>DBOX</h1> 
        <a href="AdminPage.php">USERS SONG</a>
        <a href="AdminEditView.php">CHANGE SONGS STATUS</a>
        <a href="AdminManageView.php">MANAGE USERS ACCOUNT</a>
        <a href="logout.php">LOGOUT</a>
        <h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
    </div>
	
	<div> 
		<div>
			<form method="POST">
			<div class='parent'>
			  <div class='child'>
			  	<input style="display:inline" type="text" name="search" class="search-input" placeholder="Enter keywords...">
			  </div>
			  <div class='child'>
				<input style="display:inline" type="submit" value="Search" class="search-button">
			  </div>
			</div>
			</form>
		</div>
	</div>
    

		<table border="1">
        <tr>
            <th> USER ID </th>
            <th> SONG ID </th>
            <th> SONG NAME </th>
            <th> SONG ARTIST </th>
            <th> SONG URL </th>
            <th> SONG GENRE </th>
            <th> SONG LANGUAGE </th>
            <th> SONG RELEASE DATE </th>
            <th> COMMENTS </th>
            <th> SONG STATUS </th>
        </tr>

        <?php 
        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "dbox_systemdb"; 

        $conn = new mysqli($host, $user, $pass, $db);

        if ($conn->connect_error) {
            die("connection failed: " . $conn->connect_error);
        }
        else 
        {
            $searchKeyword = isset($_POST['search']) ? $_POST['search'] : '';
            $queryView = "SELECT * FROM SONGDATA WHERE 
				Song_Id LIKE '%$searchKeyword%' OR
                Song_Name LIKE '%$searchKeyword%' OR
                Song_Artist LIKE '%$searchKeyword%' OR
				Song_URL LIKE '%$searchKeyword%' OR
                Song_Genre LIKE '%$searchKeyword%' OR
                Song_Language LIKE '%$searchKeyword%' OR
				Song_ReleaseDate LIKE '%$searchKeyword%' OR
                Comments LIKE '%$searchKeyword%' OR
                Song_Status LIKE '%$searchKeyword%' OR
				User_ID LIKE '%$searchKeyword%'
            "; 

            $resultView = $conn->query($queryView);
            
            if ($resultView->num_rows > 0) {
                while($row = $resultView->fetch_assoc()) { 
        ?>
            <tr>
                <td> <?php echo $row["User_ID"]; ?> </td>
                <td> <?php echo $row["Song_ID"]; ?> </td>
                <td> <?php echo $row["Song_Name"]; ?> </td>
                <td> <?php echo $row["Song_Artist"]; ?> </td>
				<td><a style="text-decoration: none" target="_blank" href="<?php echo $row["Song_URL"]; ?>">🔗</a></td>
                <td> <?php echo $row["Song_Genre"]; ?> </td>
                <td> <?php echo $row["Song_Language"]; ?> </td>
                <td> <?php echo $row["Song_ReleaseDate"]; ?> </td>
                <td> <?php echo $row["Comments"]; ?> </td>
                <td> <?php echo $row["Song_Status"]; ?> </td>
            </tr>

        <?php   
                }
            } else {
                echo "<tr><th colspan='10' style='color:red';'>Invalid Search</td></tr>";
            }
        }
        $conn->close();
        ?>
    </table>
	</div>
</body>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>
