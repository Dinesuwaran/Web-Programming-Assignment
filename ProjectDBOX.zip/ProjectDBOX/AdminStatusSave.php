<!DOCTYPE html>
<html lang="en">
<?php
session_start();
// Check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <meta charset="UTF-8">
    <title>DBOX</title>
</head>

<body>
    <h3>SONG UPDATE SAVE</h3>

    <?php

    $NewStatus = $_POST["status"];

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "dbox_systemdb";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $queryUpdate = "UPDATE SONGDATA SET Song_Status = '".$NewStatus."'";

        if ($conn->query($queryUpdate) === TRUE) {
            header("Location: AdminPage.php");
            exit();
        } else {
            echo "<p style='color:red;'>Query problems! :" . $conn->error . "</p>";
        }
    }

    $conn->close();
    ?>
</body>
<?php
}
else
{
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href=login.html> Login </a>";
}
?>
</html>
