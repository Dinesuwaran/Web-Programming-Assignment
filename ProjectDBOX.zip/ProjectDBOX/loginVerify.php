<?php
// this code is for the login process
// check if userID & password are matched
$userID = $_POST['userID'];
$userPwd = $_POST['userPwd'];

// declare DB connection variables
$host = "localhost";
$username = "root";
$password = ""; // please write the password if any
$dbname = "dbox_systemdb"; // please write your DB name that you have created

// create a connection with DB
$link = new mysqli($host, $username, $password, $dbname);

if ($link->connect_error) { // to check if DB connection IS NOT OK
    die("Connection failed: " . $link->connect_error); // display MySQL error
} else {
    // connect successfully
    // check if userID exists
    $queryCheck = "SELECT * FROM USERDATA WHERE UserID = '".$userID."'";

    // execute query
    $resultCheck = $link->query($queryCheck);

    if ($resultCheck->num_rows == 0) {
        echo "<p style='color:red;'><br>User ID does not exist </p>";
        echo "<br>Click <a href='login.html'> here</a> to log in again";
    } else {
        $row = $resultCheck->fetch_assoc();

        // check if the password in the database matches the password the user entered
        if ($row["UserPassword"] == $userPwd) {
            // check user status
            if ($row["UserStatus"] == 'BLOCKED') {
                echo "<p style='color:red;'><br>Your account is blocked. Please contact support. </p>";           
				echo "<br>Click <a href='login.html'> here</a> to return to the login page";
            } else {
                // calling the session_start() is compulsory
                session_start();

                // assign userID & userType values to session variables
                $_SESSION["UID"] = $userID;
                $_SESSION["UserType"] = $row["UserType"];

                // redirect to file menu.php upon successful login
                header("Location:menu.php");
            }
        } else { // if the password does not match
            echo "<p style='color:red;'><br>Wrong password!!! </p>";
            echo "Click <a href='login.html'> here</a> to log in again";
        }
    }
}

$link->close();
?>
