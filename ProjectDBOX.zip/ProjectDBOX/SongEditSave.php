<!DOCTYPE html> 
<html lang="en"> 
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head> 
    <meta charset="UTF-8"> 
    <title>DBOX</title> 
</head> 
 
<body> 
<h3> SONG UPDATE SAVE </h3> 
 
<?php 

	$SongID = $_POST ["SongID"];
	$SongName = $_POST ["songTitle"];
	$SongArtist = $_POST ["artistName"];
	$SongURL = $_POST ["songLink"];
	$SongGenre = $_POST ["genre"];
	$SongLanguage = $_POST ["language"];
	$SongReleaseDate = $_POST ["releaseDate"];
	$UserComments= $_POST ["userComment"]; 
	 
    $host = "localhost"; 
    $user = "root"; 
    $pass = ""; 
    $db = "dbox_systemdb"; 
 
    $conn = new mysqli($host, $user, $pass, $db); 
 
    if ($conn->connect_error) { 
        die("Connection failed: " . $conn->connect_error); 
      } 
 
      else 
      { 
 
      $queryUpdate = "UPDATE SONGDATA SET 
                     Song_Name = '".$SongName."', Song_Artist = '".$SongArtist."', Song_URL = '".$SongURL."', 
                     Song_Genre ='".$SongGenre."', Song_Language = '".$SongLanguage."', Song_ReleaseDate = '".$SongReleaseDate."', 
                     Comments = '".$UserComments."' WHERE Song_ID = '".$SongID."'"; 
 
    if ($conn->query($queryUpdate) === TRUE) { 
		header("Location: home.php"); 
		exit();
 
    } else { 
        echo "<p style='color:red;'>Query problems! :" . $conn->error . "</p>"; 
    } 
 
} 
$conn->close(); 
?> 
</body> 
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>