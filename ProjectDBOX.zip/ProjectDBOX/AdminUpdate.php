<!DOCTYPE html>
<html>
<?php
session_start();
// Check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('RetroWallpaper.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 125vh;
            color: white;
        }

        .MenuSelection {
            background-color: black;
            overflow: hidden;
            display: flex;
            align-items: center;
        }

        .MenuSelection a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .MenuSelection a:hover {
            background-color: #555;
        }

        .MenuSelection h1 {
            margin: 0;
            padding: 14px 16px;
            color: white;
            text-align: center;
            background-color: black;
        }

        .MenuSelection h3 {
            margin: 0;
            color: white;
            padding: 14px;
            margin-left: auto; /* This will push the h3 to the right */
        }

        h2 {
            text-align: center;
            margin-top: 20px;
            color: white;
        }

        p {
            text-align: center;
            color: #ff5555;
            font-style: italic;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            color: white;
        }

        th {
            text-align: center;
            background-color: black;
            color: white;
        }

        form {
            margin-top: 20px;
            text-align: center; /* Adjusted to align the form to the right */
        }

        input[type="radio"] {
            margin-right: 5px;
            width: 25px; 
            height: 25px;
        }

        select {
            padding: 10px; /* Adjust the padding to make the select box bigger */
            width: 120px; /* Adjust the width to your preference */
            font-size: 13px; /* Adjust the font size to your preference */
        }

        input[type="submit"] {
            background-color: black;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>

<body>
    <div class="MenuSelection">
        <h1>DBOX</h1>
        <a href="AdminPage.php">Home</a>
        <a href="AdminUpdate.php">Edit Song Status</a>
        <a href="logout.php">Logout</a>
        <h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
    </div>

    <form action="UpdateSongStatus.php" method="POST" onsubmit="return confirm('Are you sure you want to update this song status?')">
        <table border="1">
            <tr>
                <th> Song ID </th>
                <th> Song Name </th>
                <th> Song Artist </th>
                <th> Song URL </th>
                <th> Song Genre </th>
                <th> Song Language </th>
                <th> Song Release Date </th>
                <th> Comments </th>
                <th> Current Song Status </th>
                <th> Edit Song Status </th>
            </tr>

            <?php 
            $host = "localhost";
            $user = "root";
            $pass = "";
            $db = "dbox_systemdb"; 

            $conn = new mysqli($host, $user, $pass, $db);

            if ($conn->connect_error) {
                die("connection failed: " . $conn->connect_error);
            }
            else 
            {
                $queryView = "SELECT * FROM SONGDATA"; 
                $resultView = $conn->query($queryView);
                
                if ($resultView->num_rows > 0) {
                    while($row = $resultView->fetch_assoc()) { 
            ?>
                        <tr>
                            <td> <?php echo $row["Song_ID"]; ?> </td>
                            <td> <?php echo $row["Song_Name"]; ?> </td>
                            <td> <?php echo $row["Song_Artist"]; ?> </td>
                            <td> <?php echo $row["Song_URL"]; ?> </td>
                            <td> <?php echo $row["Song_Genre"]; ?> </td>
                            <td> <?php echo $row["Song_Language"]; ?> </td>
                            <td> <?php echo $row["Song_ReleaseDate"]; ?> </td>
                            <td> <?php echo $row["Comments"]; ?> </td>
                            <td> <?php echo $row["Song_Status"]; ?> </td>
                            <td> 
                                <select name="status" id="status" required>
                                    <option value="APPROVED">APPROVED</option>
                                    <option value="REJECTED">REJECTED</option>
                                </select>
                            </td>
                        </tr>
            <?php   
                    }
                } else {
                    echo "<tr><th colspan='9' style='color:red';'>No Data Selected</td></tr>";
                }
            }
            $conn->close();
            ?>
        </table>

        <input type="submit" value="UPDATE SELECTED SONG STATUS">
    </form>
</body>
<?php
}
else
{
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href=login.html> Login </a>";
}
?>
</html>
