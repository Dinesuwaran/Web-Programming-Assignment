<!DOCTYPE html>
<html>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
<title>DBOX</title>

<?php
$SongID = $_POST["SongID"]; 
?>

<body>
<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "dbox_systemdb"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
else
{
	$queryDelete = "DELETE FROM SONGDATA WHERE Song_ID = '".$SongID."' ";
	
	if ($conn->query($queryDelete) === TRUE) {
		header("Location: home.php"); 
		exit();
	} else {
		echo "<p style='color:red;' >Query problems! : " , $conn->error . "</p>";
	}
}
$conn->close();
?>
</body>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>	