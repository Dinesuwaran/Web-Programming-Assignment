<!DOCTYPE html>
<html>
<?php
session_start();
// check if session exists
if (isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
</head>

<body>
    <?php

    $SongID = $_POST["SongID"];

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "dbox_systemdb";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {

        $queryGet = "SELECT * FROM SONGDATA WHERE Song_ID = '" . $SongID . "'";

        $resultGet = $conn->query($queryGet);

        if ($resultGet->num_rows > 0) {
    ?>

            <div class="MenuSelection">
                <h1>DBOX</h1>
				<a href="AdminPage.php">USERS SONG</a>
				<a href="AdminEditView.php">CHANGE SONGS STATUS</a>
				<a href="AdminManageView.php">MANAGE USERS ACCOUNT</a>
				<a href="logout.php">LOGOUT</a>
				<h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
            </div>

            <form class=form action="AdminEditSave.php" method="POST">
                <?php
                while ($row = $resultGet->fetch_assoc()) {
                ?>

                    <label for="songTitle">TITLE OF THE SONG :</label>
                    <?php echo $row['Song_Name']; ?> <br><br>

                    <label for="artistName">ARTIST OR BAND NAME :</label>
                    <?php echo $row['Song_Artist']; ?> <br><br>

                    <label for="songLink">SONG URL :</label>
                    <a style="text-decoration: none" target="_blank" href="<?php echo $row['Song_URL']; ?>">🔗</a> <br><br>

                    <div class="language-section">
                        <label>SONG LANGUAGE : </label>
                        <?php $Song_Language = $row['Song_Language']; ?>
                        <?php if ($Song_Language == "Malay") echo "Malay"; ?>
                        <?php if ($Song_Language == "English") echo "English"; ?>
                        <?php if ($Song_Language == "Chinese") echo "Chinese"; ?>
                        <?php if ($Song_Language == "Tamil") echo "Tamil"; ?>
                    </div>

                    <label for="Genre">SONG GENRE :</label>
                    <?php $Song_Genre = $row['Song_Genre']; ?>
                    <?php echo $Song_Genre; ?> <br><br>

                    <label for="releaseDate">RELEASE DATE :</label>
                    <?php echo $row['Song_ReleaseDate']; ?> <br><br>

                    <label for="userComment">USER COMMENT :</label>
                    <?php echo $row['Comments']; ?> <br><br>

                    <label for="songStatus">CHANGE SONG STATUS :</label>
                    <select name="songStatus" required>
                        <option value="APPROVED" <?php echo ($row['Song_Status'] == "APPROVED") ? 'selected' : ''; ?>>APPROVED</option>
                        <option value="REJECTED" <?php echo ($row['Song_Status'] == "REJECTED") ? 'selected' : ''; ?>>REJECTED</option>
                    </select> <br><br>

                    <input type="hidden" name="SongID" value="<?php echo $row["Song_ID"]; ?>">
                    <input type="submit" value="UPDATE SONG STATUS">
                    <input type="reset" value="CANCEL" onclick="window.location.href='AdminEditView.php';">
                <?php
                }
                ?>
            </form>
    <?php
        }
    }
    $conn->close();
    ?>
</body>
<?php
} else {
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href=login.html> Login </a>";
}
?>
</html>

