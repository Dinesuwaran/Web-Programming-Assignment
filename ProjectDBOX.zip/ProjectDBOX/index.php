<!DOCTYPE html>
<html>
<?php
session_start();
// check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>
    <link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
    <style>
        .OurAim {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            text-align: center;
            background-color: black;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .OurAim h3,
        .OurAim p {
			font-size: 20px;
            color: white;
        }

        .Developers {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            text-align: center;
            background-color: black;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .Developers h3{
			font-size: 25px;
			text-decoration: underline;
			margin: 15px;
		}
        .Member p,
        .Member strong {
            color: white;
        }

        .Member {
            display: flex;
            margin-top: 20px;
            text-align: center;
        }

        .Member .MemberCard {
            flex: 1;
            margin: 10px;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: black;
        }

        .Member img {
            width: 150px; 
            height: 150px; 
            border-radius: 0%; 
            margin: 2px; 
			margin-left: 2px;
			margin-right: 2px;
            object-fit: cover; 
        }
    </style>
</head>

<?php 
	include 'Navbar.php';
?>

<body>

    <div class="OurAim">
        <h3>Welcome to DBOX Song Collection System</h3>
        <p>In DBOX, you can add songs of your choice and organize your amazing song collections.</p>
        <p>We aim to provide you with a website to manage and enjoy your song collections.</p>
    </div>

    <div class="Developers">
        <h3>Meet Our Team</h3>
        <div class="Member">
            <div class="MemberCard">
                <img src="Dinesuwaran1.jpeg" alt="Dinesuwaran's Picture">
				<p>Dinesuwaran A/L Nadarajah</p>
            </div>
            <div class="MemberCard">
                <img src="Jaspreet1.jpeg" alt="Jaspreet's Picture">
				<p>Jaspreet Singh</p>
            </div>
            <div class="MemberCard">
                <img src="Amir1.jpeg" alt="Amir's Picture">
				<p>Amir ‘Aizat Bin Harith</p>
            </div>
            <div class="MemberCard">
                <img src="Haikal1.jpeg" alt="Haikal's Picture">
				<p>Muhammad Haikal Azmir</p>
            </div>
            <div class="MemberCard">
                <img src="Hilmat1.jpeg" alt="Hilmat's Picture">
				<p>Muhamad Hilman Zainorin</p>
            </div>
        </div>
    </div>
</body>
<?php
}
else
{
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href=login.html> Login </a>";
}
?>
</html>
