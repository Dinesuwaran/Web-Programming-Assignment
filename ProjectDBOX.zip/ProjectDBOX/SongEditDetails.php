<!DOCTYPE html>
<html>
	<?php
		session_start();
		//check if session exists
		if(isset($_SESSION["UID"])) {
	?>
<head>
    <title>DBOX</title>
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css"> 
</head>
<body>
	<?php 
		include 'Navbar.php';
	?>
	
	<?php 
	
	$SongID = $_POST ["SongID"]; 
	$host = "localhost"; 
	$user = "root"; 
	$pass = ""; 
	$db = "dbox_systemdb"; 
	 
	$conn = new mysqli($host, $user, $pass, $db); 
	 
	if ($conn->connect_error) { 
	  die("Connection failed: " . $conn->connect_error); 
	} 
	else 
	{ 
	$queryGet= "SELECT * FROM SONGDATA WHERE Song_ID = '".$SongID."'"; 
	 
	$resultGet = $conn->query($queryGet); 
	 
	if ($resultGet->num_rows > 0) {  
	?> 

    <form class=form name="SongUpdateForm" action="SongEditSave.php" method="POST" onsubmit="return confirm('Are you sure you want to EDIT this song?')">
		<?php 
			while ($row = $resultGet->fetch_assoc()) { 
		?> 
		
		Song ID : <?php echo $row["Song_ID"];?> <br><br>
		
        <label for="songTitle">Title of the Song :</label>
        <input type="text" name="songTitle" value="<?php echo $row['Song_Name'];?>" maxlength="100" required>

        <label for="artistName">Artist or Band Name :</label>
        <input type="text" name="artistName" value="<?php echo $row['Song_Artist'];?>" maxlength="30" required>

        <label for="songLink">URL of the Song :</label>
        <input type="url" name="songLink" value="<?php echo $row['Song_URL'];?>" required>

        <div class="language-section">
            <label>Song<br>Language :</label>
			<?php $Song_Language = $row['Song_Language'];?> 
            <input type="radio" name="language" value="Malay" <?php if ($Song_Language == "Malay") echo "checked"; ?> required>Malay
            <input type="radio" name="language" value="English" <?php if ($Song_Language == "English") echo "checked"; ?> required>English
            <input type="radio" name="language" value="Chinese" <?php if ($Song_Language == "Chinese") echo "checked"; ?> required>Chinese
            <input type="radio" name="language" value="Tamil" <?php if ($Song_Language == "Tamil") echo "checked"; ?> required>Tamil
        </div>

        <label for="Genre">Genre of the Song :</label>
        <select name="genre" required>
			<?php $Song_Genre = $row['Song_Genre'];?> 
			<option value="Alternative/Indie" <?php if ($Song_Genre == "Alternative/Indie") echo "selected"; ?> >Alternative/Indie</option>
			<option value="R&B/Soul" <?php if ($Song_Genre == "R&B/Soul") echo "selected"; ?> >R&B/Soul</option>
            <option value="Pop" <?php if ($Song_Genre == "Pop") echo "selected"; ?> >Pop</option>
            <option value="Rock" <?php if ($Song_Genre == "Rock") echo "selected"; ?> >Rock</option>
            <option value="Jazz" <?php if ($Song_Genre == "Jazz") echo "selected"; ?> >Jazz</option>
            <option value="Hip-Hop/Rap" <?php if ($Song_Genre == "Hip-Hop/Rap") echo "selected"; ?> >Hip-Hop/Rap</option>
        </select>

        <label for="releaseDate">Release Date of the Song :</label>
        <input type="date" name="releaseDate" value="<?php echo $row['Song_ReleaseDate'];?>" required>

        <label for="userComment">Comments :</label>
        <textarea name="userComment" rows="4" cols="40" required><?php echo $row['Comments'];?></textarea>

		<?php 
		 
		?> 
		 
		<input type="hidden" name="SongID" value="<?php echo $row["Song_ID"];?>"> 
		<input type="submit" value="UPDATE SONG RECORD"> 
		<input type="reset" value="CANCEL" onclick="window.location.href='home.php';">
		 
		<?php 
			} 
		  } 
		}  
		$conn->close(); 
		?> 
		 
    </form>
</body>
	<?php
		}
		else
		{
		echo "No session exists or session has expired. Please
		log in again.<br>";
		echo "<a href=login.html> Login </a>";
		}
	?>
</html>
