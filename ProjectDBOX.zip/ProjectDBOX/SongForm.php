<!DOCTYPE html>
<html>
	<?php
		session_start();
		//check if session exists
		if(isset($_SESSION["UID"])) {
	?>
<head>
    <title>DBOX</title>
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
</head>
<body>
	<?php 
		include 'Navbar.php';
	?>
    <form class=form name="SongDetailsForm" action="SongDisplay.php" method="POST">
        <label for="songTitle">Title of the Song :</label>
        <input type="text" name="songTitle" maxlength="100" required>

        <label for="artistName">Artist or Band Name :</label>
        <input type="text" name="artistName" maxlength="30" required>

        <label for="songLink">URL of the Song :</label>
        <input type="url" name="songLink" required>

        <div class="language-section">
            <label>Song Language :</label>
            <input type="radio" name="language" value="Malay" checked required>Malay
            <input type="radio" name="language" value="English" required>English
            <input type="radio" name="language" value="Chinese" required>Chinese
            <input type="radio" name="language" value="Tamil" required>Tamil
        </div>

        <label for="Genre">Genre of the Song :</label>
        <select name="genre" required>
            <option value="-">-Please Choose-</option>
			<option value="Alternative/Indie">Alternative/Indie</option>
			<option value="R&B/Soul">R&B/Soul</option>
            <option value="Pop">Pop</option>
            <option value="Rock">Rock</option>
            <option value="Jazz">Jazz</option>
            <option value="Hip-Hop/Rap">Hip-Hop/Rap</option>
        </select>

        <label for="releaseDate">Release Date of the Song :</label>
        <input type="date" name="releaseDate" required>

        <label for="userComment">Comments :</label>
        <textarea class=comment name="userComment" rows="4" cols="40" required></textarea>

        <input type="submit" value="ADD SONG">
        <input type="reset" value="CANCEL">
    </form>
</body>
	<?php
		}
		else
		{
		echo "No session exists or session has expired. Please
		log in again.<br>";
		echo "<a href=login.html> Login </a>";
		}
	?>
</html>
