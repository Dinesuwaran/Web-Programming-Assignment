<div class="MenuSelection">
	<!-- <a href="home.php">
		<h1>DBOX</h1>
	</a> -->
	<!-- <a href="home.php">HOME</a> -->
	<h1>DBOX</h1>
	<a href="MySongs.php">MY SONGS</a>
	<a href="home.php">COMMUNITY SONGS</a>
	<a href="SongForm.php">ADD SONG RECORD</a>
	<a href="SongEditView.php">EDIT SONG RECORD</a>
	<a href="SongDeleteView.php">DELETE SONG RECORD</a>
	<a href="index.php">ABOUT US</a>
	<a href="logout.php">LOGOUT</a>
	<h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
</div>
