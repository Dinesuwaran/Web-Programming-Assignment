<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
<table border="1">
        <tr>
            <!-- <th> SONG ID </th> -->
            <th> SONG NAME </th>
            <th> SONG ARTIST </th>
            <th> SONG URL </th>
            <th> SONG GENRE </th>
            <th> SONG LANGUAGE </th>
            <th> SONG RELEASE DATE </th>
            <th> COMMENTS </th>
			<th> UPLOADER USERNAME </th>
        </tr>

        <?php 
        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "dbox_systemdb"; 

        $conn = new mysqli($host, $user, $pass, $db);

        if ($conn->connect_error) {
            die("connection failed: " . $conn->connect_error);
        }
        else 
        {
			$queryView = "SELECT * FROM SONGDATA where User_ID = '".$_SESSION['UID']."'"; 
            $resultView = $conn->query($queryView);
            
            if ($resultView->num_rows > 0) {
                while($row = $resultView->fetch_assoc()) { 
        ?>
            <tr>
                <!--<td> <?php echo $row["Song_ID"]; ?> </td> -->
                <td> <?php echo $row["Song_Name"]; ?> </td>
                <td> <?php echo $row["Song_Artist"]; ?> </td>
				<td><a style="text-decoration: none" target="_blank" href="<?php echo $row["Song_URL"]; ?>">🔗</a></td>
                <td> <?php echo $row["Song_Genre"]; ?> </td>
                <td> <?php echo $row["Song_Language"]; ?> </td>
                <td> <?php echo $row["Song_ReleaseDate"]; ?> </td>
                <td> <?php echo $row["Comments"]; ?> </td>
				<td> <?php echo $row["User_ID"]; ?> </td>
            </tr>

        <?php   
                }
            } else {
                echo "<tr><th colspan='7' style='color:red';'>No Data Selected</td></tr>";
            }
        }
        $conn->close();
        ?>
    </table>