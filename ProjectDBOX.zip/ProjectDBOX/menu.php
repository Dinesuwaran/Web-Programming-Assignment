<?php
session_start();
if(isset ($_SESSION["UID"])) {

?>
<html>
<head>
<title>DBOX</title>
</head>
<body>

<?php
if ($_SESSION["UserType"] == "Admin"){
	    header("Location: AdminPage.php");
		exit();
    ?>

    header("Location: home.php");

    <?php
}
else {
	header("Location: index.php");
    exit();
?>

<?php
}
?>
<a href="logout.php">Logout</a><br>
</body>
</html>
<?php
}
else
{
    echo "No session exist or session has expired. Please log in again.<br>";
    echo "<a href='login.html'> Login </a>";
}
?>