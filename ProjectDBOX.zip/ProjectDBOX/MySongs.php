<!DOCTYPE html>
<html>
	<?php
		session_start();
		//check if session exists
		if(isset($_SESSION["UID"])) {
	?>
<head>
    <title>DBOX</title>
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
</head>
<body>
	<?php 
		include 'Navbar.php';
		include 'Table.php';
	?>
</body>
	<?php
		}
		else
		{
		echo "No session exists or session has expired. Please
		log in again.<br>";
		echo "<a href=login.html> Login </a>";
	}
	?>
</html>
