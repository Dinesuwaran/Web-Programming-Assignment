<!DOCTYPE html>
<html>
<?php
session_start();
// check if session exists
if (isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
    <style>
        form {
            max-width: 580px; 
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.8); /* Changed background color to black with transparency */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: white; /* Changed font color to white */
			font-size: 20px; /* Adjust the font size as needed */
			font-family: 'Geneva', sans-serif; 
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: white; /*Font Color inside Form*/
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: black; /* Changed font color to black */
			font-size: 17px; /* Adjust the font size as needed */
			font-family: 'Geneva', sans-serif; 
        }

        .language-section {
			margin-left: auto;
            margin-bottom: 15px;
        }

        .language-section label {
            margin-left: 0px;
        }

        input[type="submit"],
        input[type="reset"] {
            background-color: black;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;	
			font-size: 18px;			
			font-family: 'Verdana', Tahoma, Geneva, Verdana, sans-serif;
        }

        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #333;
			font-size: 18px;
			font-family: 'Verdana', Tahoma, Geneva, Verdana, sans-serif;
        }

        p {
            color: red;
            font-style: italic;
        }
    </style>
</head>

<body>
    <?php

    $UserID = $_POST["UserID"];

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "dbox_systemdb";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {

        $queryGet = "SELECT * FROM USERDATA WHERE UserID = '" . $UserID . "'";

        $resultGet = $conn->query($queryGet);

        if ($resultGet->num_rows > 0) {
    ?>

            <div class="MenuSelection">
				<h1>DBOX</h1>
					<a href="AdminPage.php">USERS SONG</a>
					<a href="AdminEditView.php">CHANGE SONGS STATUS</a>
					<a href="AdminManageView.php">MANAGE USERS ACCOUNT</a>
					<a href="logout.php">LOGOUT</a>
				<h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
            </div>

            <form style="zoom:0.75" action="AdminManageSave.php" method="POST">
                <?php
                while ($row = $resultGet->fetch_assoc()) {
                ?>

                    <label for="userName">USER ID :</label>
                    <?php echo $row['UserID']; ?> <br><br>

                    <label for="userStatus">CHANGE USER STATUS :</label>
                    <select name="userStatus" required>
                        <option value="ACTIVE" <?php echo ($row['UserStatus'] == "ACTIVE") ? 'selected' : ''; ?>>ACTIVE</option>
                        <option value="BLOCKED" <?php echo ($row['UserStatus'] == "BLOCKED") ? 'selected' : ''; ?>>BLOCKED</option>
                    </select> <br><br>

                    <input type="hidden" name="UserID" value="<?php echo $row["UserID"]; ?>">
                    <input type="submit" value="UPDATE USER STATUS">
                    <input type="reset" value="CANCEL" onclick="window.location.href='AdminManageView.php';">
                <?php
                }
                ?>
            </form>
    <?php
        }
    }
    $conn->close();
    ?>
</body>
<?php
} else {
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href=login.html> Login </a>";
}
?>
</html>

