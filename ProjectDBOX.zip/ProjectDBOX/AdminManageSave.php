<!DOCTYPE html> 
<html lang="en"> 
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head> 
    <meta charset="UTF-8"> 
    <title>DBOX</title> 
</head> 
 
<body> 
<h3> SONG UPDATE SAVE </h3> 
 
<?php 

	$UserID = $_POST ["UserID"];
	$UserStatus= $_POST ["userStatus"];
	
    $host = "localhost"; 
    $user = "root"; 
    $pass = ""; 
    $db = "dbox_systemdb"; 
 
    $conn = new mysqli($host, $user, $pass, $db); 
 
    if ($conn->connect_error) { 
        die("Connection failed: " . $conn->connect_error); 
      } 
 
      else 
      { 
 
      $queryUpdate = "UPDATE USERDATA SET 
                      UserStatus = '".$UserStatus."' WHERE USERID = '".$UserID."'"; 
 
    if ($conn->query($queryUpdate) === TRUE) { 
		header("Location: AdminManageView.php"); 
		exit();
 
    } else { 
        echo "<p style='color:red;'>Query problems! :" . $conn->error . "</p>"; 
    } 
 
} 
$conn->close(); 
?> 
</body> 
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>