<!DOCTYPE html>
<html>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('RetroWallpaper.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 125vh;
            color: white;
        }

        .MenuSelection {
            background-color: black;
            overflow: hidden;
            display: flex;
            align-items: center;
        }

        .MenuSelection a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .MenuSelection a:hover {
            background-color: #555;
        }

        .MenuSelection h1 {
            margin: 0;
            padding: 14px 16px;
            color: white;
            text-align: center;
            background-color: black;
        }

        .MenuSelection h3 {
            margin: 0;
            color: white;
            padding: 14px;
            margin-left: auto; /* This will push the h3 to the right */
        }

        h2 {
            text-align: center;
            margin-top: 20px;
            color: white;
        }

        p {
            text-align: center;
            color: #ff5555;
            font-style: italic;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            color: white;
        }

        th {
            text-align: center;
            background-color: black;
            color: white;
        }

        form {
            margin: 20px auto;
            text-align: center;
        }

        input[type="radio"] {
            margin-right: 5px;
            width: 25px; /* Adjusted width for larger radio button */
            height: 25px; /* Adjusted height for larger radio button */
        }

        input[type="submit"] {
            background-color: black;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px; /* Adjusted margin for spacing */
        }

        input[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>

<body>
    <div class="MenuSelection">
        <h1>DBOX</h1>
        <a href="AdminPage.php">Home</a>
		<a href="AdminEditView.php">Edit Song Status</a>
		<a href="AdminManageAccount.php">Manage Users Account</a>
        <a href="logout.php">Logout</a>
        <h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
    </div>

    <form action="AdminEditDetails.php" method="POST" onsubmit="return confirm('Are you sure you want to EDIT this song status?')">
        <table border="1">
            <tr>
                <th> USERNAME </th>
                <th> USER STATUS </th>
                <th> Change User Status </th>
            </tr>

            <?php 
            $host = "localhost";
            $user = "root";
            $pass = "";
            $db = "dbox_systemdb"; 

            $conn = new mysqli($host, $user, $pass, $db);

            if ($conn->connect_error) {
                die("connection failed: " . $conn->connect_error);
            }
            else 
            {
                $queryView = "SELECT * FROM USERDATA WHERE UserType = 'User'; "; 
                $resultView = $conn->query($queryView);
                
                if ($resultView->num_rows > 0) {
                    while($row = $resultView->fetch_assoc()) { 
            ?>
                        <tr>
                            <td> <?php echo $row["UserID"]; ?> </td>
                            <td> <?php echo $row["UserStatus"]; ?> </td>
							<td><select name="UserID" required>
							<option value="ACTIVE" <?php echo ($row['UserStatus'] == "ACTIVE") ? 'selected' : ''; ?>>ACTICE</option>
							<option value="BLOCKED" <?php echo ($row['UserStatus'] == "BLOCKED") ? 'selected' : ''; ?>>BLOCKED</option>
							</select></td>
                        </tr>

            <?php   
                    }
                } else {
                    echo "<tr><th colspan='7' style='color:red';'>No Data Selected</td></tr>";
                }
            }
            $conn->close();
            ?>
        </table>
        <input type="submit" value="EDIT SELECTED USER STATUS">
    </form>
</body>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>
