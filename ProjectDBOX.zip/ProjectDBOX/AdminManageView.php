<!DOCTYPE html>
<html>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>
	<link rel="stylesheet" type="text/css" href="WebsiteMenuStyle.css">
</head>

<body>
    <div class="MenuSelection">
        <h1>DBOX</h1>
			<a href="AdminPage.php">USERS SONG</a>
			<a href="AdminEditView.php">CHANGE SONGS STATUS</a>
			<a href="AdminManageView.php">MANAGE USERS ACCOUNT</a>
			<a href="logout.php">LOGOUT</a>
        <h3><sub>Logged in as, <?php echo $_SESSION["UID"]; ?></sub></h3>
    </div>

    <form class=viewform action="AdminManageDetails.php" method="POST">
        <table border="1">
            <tr>
                <th> USER ID </th>
                <th> USER STATUS </th>
                <th> CHANGE USER STATUS </th>
            </tr>

            <?php 
            $host = "localhost";
            $user = "root";
            $pass = "";
            $db = "dbox_systemdb"; 

            $conn = new mysqli($host, $user, $pass, $db);

            if ($conn->connect_error) {
                die("connection failed: " . $conn->connect_error);
            }
            else 
            {
                $queryView = "SELECT * FROM USERDATA WHERE UserType = 'User'; "; 
                $resultView = $conn->query($queryView);
                
                if ($resultView->num_rows > 0) {
                    while($row = $resultView->fetch_assoc()) { 
            ?>
                        <tr>
                            <td> <?php echo $row["UserID"]; ?> </td>
                            <td> <?php echo $row["UserStatus"]; ?> </td>
                            <td> <input type="radio" name="UserID" value="<?php echo $row["UserID"]; ?>" required> </td>
                        </tr>

            <?php   
                    }
                } else {
                    echo "<tr><th colspan='7' style='color:red';'>No Data Selected</td></tr>";
                }
            }
            $conn->close();
            ?>
        </table>
		<div class=buttonwidth>
			<input type="submit" value="MANAGE SELECTED USER STATUS">
		</div>
    </form>
</body>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>
