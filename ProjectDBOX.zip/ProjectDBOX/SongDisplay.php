<!DOCTYPE html>
<html>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>
<head>
    <title>DBOX</title>

</head>

<! PHP Codes To Connect with Database>
<?php

$SongName = $_POST ["songTitle"];
$SongArtist = $_POST ["artistName"];
$SongURL = $_POST ["songLink"];
$SongGenre = $_POST ["genre"];
$SongLanguage = $_POST ["language"];
$SongReleaseDate = $_POST ["releaseDate"];
$UserComments= $_POST ["userComment"];

?>

<body>

	<!Connection With Database> 
	<?php 
	//declaring DB variables
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "dbox_systemdb"; 

	//creating connection
	$conn = new mysqli($host, $user, $pass, $db);

	//checking connection
	if ($conn->connect_error) {
		die("connection failed: " . $conn->connect_error);
	}
	else 
	{
		$queryInsert = "insert into SONGDATA(Song_Name, Song_Artist, Song_URL, Song_Genre, Song_Language, Song_ReleaseDate, Comments, User_ID)
		values
		('".$SongName."', '".$SongArtist."', '".$SongURL."', '".$SongGenre."', '".$SongLanguage."', '".$SongReleaseDate."', '".$UserComments."', '".$_SESSION["UID"]."')";
		
		if ($conn->query($queryInsert) === TRUE){
				header("Location: home.php"); 
				exit();
		} else {
			echo "<p style='color:red;'>Error: Invalid query" . $conn->error. "</p>";
		}
	}
	$conn->close();
	?>

</body>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
</html>
